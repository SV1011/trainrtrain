package com.example.training;

import java.time.LocalDate;
import java.util.Date;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import java.lang.Integer;

import javax.servlet.annotation.WebServlet;

import com.vaadin.ui.Notification;
import com.vaadin.shared.Position;
import com.vaadin.server.Page;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;

@Theme("trainingtheme")
public class MyUI extends UI {
		//Class for vector of elements
		private class tabObject {
			String petName;
			String petType;
			String petGender;
			LocalDate date;
			String name;
			String phoneNumber;
			String eMail;
			public int id;
			tabObject(String q, String w, String e, LocalDate r, String t, String y, String u) {
				this.petName = q;
				this.petType = w;
				this.petGender = e;
				this.date = r;
				this.name = t;
				this.phoneNumber = y;
				this.eMail = u;
			}
			String getPetName() { return this.petName; }
			String getPetType() { return this.petType; }
			String getPetGender() { return this.petGender; }
			String getDate() { return this.date.toString(); }
			String getName() { return this.name; }
			String getPhoneNumber() { return this.phoneNumber; }
			String getEMail() { return this.eMail; }
		}
		
		static int currentID = 0;
    @Override
    protected void init(VaadinRequest vaadinRequest) {
    	//Variable for change form
    	//Errors and notifications
    	Notification tooMuchSelected = new Notification("Ошибка", "Выделено более одного элемента",
    			Notification.Type.ERROR_MESSAGE);
    	tooMuchSelected.setPosition(Position.TOP_LEFT);
    	Notification notSelected = new Notification("Ошибка", "Не выделено ни одного элемента для редактирования",
    			Notification.Type.ERROR_MESSAGE);
    	notSelected.setPosition(Position.TOP_LEFT);
    	//All layouts
    	HorizontalLayout mainLayout = new HorizontalLayout();
    	VerticalLayout lineLeft = new VerticalLayout();
    	VerticalLayout lineRight = new VerticalLayout();
    	HorizontalLayout petTypeGenderLayout = new HorizontalLayout();
    	HorizontalLayout petTypeGenderLayoutChange = new HorizontalLayout();
        //Form for adding items
    	TextField petName = new TextField("Имя животного");
    	ComboBox<String> petType = new ComboBox<>("Тип жив.");
    	ComboBox<String> petGender = new ComboBox<>("Пол жив.");
    	DateField date = new DateField("Дата рождения животного");
    	TextField name = new TextField("ФИО хозяина");
    	TextField phoneNumber = new TextField("Номер телефона");
    	TextField eMail = new TextField("E-Mail");
    	Button send = new Button("Отправить в БД");
    	Button delete = new Button("Удалить");
    	Button edit = new Button("Изменить");
    	//Form for edit slected item
    	TextField petNameChange = new TextField("Имя животного");
    	ComboBox<String> petTypeChange = new ComboBox<>("Тип жив.");
    	ComboBox<String> petGenderChange = new ComboBox<>("Пол жив.");
    	DateField dateChange = new DateField("Дата рождения животного");
    	TextField nameChange = new TextField("ФИО хозяина");
    	TextField phoneNumberChange = new TextField("Номер телефона");
    	TextField eMailChange = new TextField("E-Mail");
    	Button buttonChange = new Button("Созранить изменения");
    	//Seting elements of edit form unvisible
    	petNameChange.setVisible(false);
    	petTypeGenderLayoutChange.setVisible(false);
    	dateChange.setVisible(false);
    	nameChange.setVisible(false);
    	phoneNumberChange.setVisible(false);
    	eMailChange.setVisible(false);
    	buttonChange.setVisible(false);
    	//Seting comboboxes
    	petType.setItems("Кошка", "Собака");
    	petGender.setItems("Мужской", "Женский");
    	petTypeChange.setItems("Кошка", "Собака");
    	petGenderChange.setItems("Мужской", "Женский");
    	//Seting date
    	date.setValue(LocalDate.now());
    	//Vector of elements and table
    	Vector<tabObject> lines =  new Vector();
    	Grid<tabObject> mainTable = new Grid<>();
    	//Initalizing columns of table
    	mainTable.setSelectionMode(SelectionMode.MULTI);
    	mainTable.addColumn(tabObject::getPetName).setCaption("Имя животного");
    	mainTable.addColumn(tabObject::getPetType).setCaption("Тип животного");
    	mainTable.addColumn(tabObject::getPetGender).setCaption("Пол животного");
    	mainTable.addColumn(tabObject::getDate).setCaption("Дата рождения");
    	mainTable.addColumn(tabObject::getName).setCaption("ФИО хозяина");
    	mainTable.addColumn(tabObject::getPhoneNumber).setCaption("Номер телефона");
    	mainTable.addColumn(tabObject::getEMail).setCaption("Почта");
    	mainTable.setItems(lines);
    	//Event for "Отправить в БД" button
    	send.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(ClickEvent event) {
				lines.add(new tabObject(petName.getValue(), petType.getValue(), petGender.getValue(),
						date.getValue(), name.getValue(), phoneNumber.getValue(), eMail.getValue()));
				for(int d=0; d<lines.size(); d++){
					lines.get(d).id=d;
				}
				mainTable.setItems(lines);			
			}
		});
    	//Event for "Изменить" button
    	edit.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(ClickEvent event) {
		    	Vector<tabObject> w = new Vector(mainTable.getSelectedItems());
		    	if (w.size() > 1) tooMuchSelected.show(Page.getCurrent());
		    	else if (w.size() == 0) notSelected.show(Page.getCurrent());
		    	else {
		    		petName.setVisible(false);
					petTypeGenderLayout.setVisible(false);
			    	date.setVisible(false);
			    	name.setVisible(false);
			    	phoneNumber.setVisible(false);
			    	eMail.setVisible(false);
			    	send.setVisible(false);
			    	edit.setVisible(false);
			    	delete.setVisible(false);
			 
			    	petNameChange.setVisible(true);
					petTypeGenderLayoutChange.setVisible(true);
			    	dateChange.setVisible(true);
			    	nameChange.setVisible(true);
			    	phoneNumberChange.setVisible(true);
			    	eMailChange.setVisible(true);
			    	buttonChange.setVisible(true);
			    	
			    	for(int a = 0; a < w.size(); a++){
						for(int g = 0; g < lines.size(); g++){
							if(w.get(a).id == lines.get(g).id){
								currentID = g;
								break;
							}
						}
					}
			    	
			    	petNameChange.setValue(lines.get(currentID).petName);
			    	petTypeChange.setValue(lines.get(currentID).petType);
			    	petGenderChange.setValue(lines.get(currentID).petGender);
			    	dateChange.setValue(lines.get(currentID).date);
			    	nameChange.setValue(lines.get(currentID).name);
			    	phoneNumberChange.setValue(lines.get(currentID).phoneNumber);
			    	eMailChange.setValue(lines.get(currentID).eMail);
		    	}
			}
		});
    	//Event for "Удалить" button
    	delete.addClickListener(new Button.ClickListener() {	
			@Override
			public void buttonClick(ClickEvent event) {
				Vector<tabObject> w = new Vector(mainTable.getSelectedItems());
				for(int a = 0; a < w.size(); a++){
					for(int g = 0; g < lines.size(); g++){
						if(w.get(a).id == lines.get(g).id){
							lines.remove(g);
							break;
						}
					}
				}
				for(int s = 0; s < lines.size(); s++){
					lines.get(s).id = s;
				}
				mainTable.setItems(lines);
			}
		});
    	//Event for "Сохранить изменения" button
    	buttonChange.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(ClickEvent event) {
				tabObject x = new tabObject(petNameChange.getValue(), petTypeChange.getValue(), petGenderChange.getValue(),
						dateChange.getValue(), nameChange.getValue(), phoneNumberChange.getValue(), eMailChange.getValue());
				lines.set(currentID, x);
				
				petName.setVisible(true);
				petTypeGenderLayout.setVisible(true);
		    	date.setVisible(true);
		    	name.setVisible(true);
		    	phoneNumber.setVisible(true);
		    	eMail.setVisible(true);
		    	send.setVisible(true);
		    	edit.setVisible(true);
		    	delete.setVisible(true);
		 
				petNameChange.setVisible(false);
				petTypeGenderLayoutChange.setVisible(false);
		    	dateChange.setVisible(false);
		    	nameChange.setVisible(false);
		    	phoneNumberChange.setVisible(false);
		    	eMailChange.setVisible(false);
		    	buttonChange.setVisible(false);	
		    	
		    	mainTable.setItems(lines);
			}
		});
    	//Seting styles for basic table and layouts
    	mainLayout.setHeight("100%");
    	lineLeft.setStyleName("leftPanel");
    	lineLeft.setWidth("151px");
    	lineRight.setWidth("100%");
    	lineRight.setStyleName("rightPanel");
    	mainTable.setWidth("900px");
    	mainTable.setHeight("500px");
    	//Adding components
    	petTypeGenderLayout.addComponents(petType, petGender);
    	petTypeGenderLayoutChange.addComponents(petTypeChange, petGenderChange);
    	lineLeft.addComponents(petName, petTypeGenderLayout, date, name, phoneNumber, eMail, send, edit, delete,
    			petNameChange, petTypeGenderLayoutChange, dateChange, nameChange, phoneNumberChange, eMailChange, 
    			buttonChange);
    	lineRight.addComponent(mainTable);
    	mainLayout.addComponent(lineLeft);
    	mainLayout.addComponent(lineRight);
    	
        setContent(mainLayout);
    }

    @WebServlet(urlPatterns = "/*", name = "MyUIServlet", asyncSupported = true)
    @VaadinServletConfiguration(ui = MyUI.class, productionMode = false)
    public static class MyUIServlet extends VaadinServlet {
    }
}
